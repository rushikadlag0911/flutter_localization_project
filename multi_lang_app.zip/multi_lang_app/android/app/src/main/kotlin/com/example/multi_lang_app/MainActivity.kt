package com.example.multi_lang_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
