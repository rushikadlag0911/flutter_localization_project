import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'l10n/gen_l10n/app_localizations.dart';
import 'login_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'Flutter Localization Example',
      supportedLocales: [
        Locale('en', 'US'), // English
        Locale('hi', 'IN'), // Hindi
        Locale('mr', 'IN'), // Marathi
      ],
      localizationsDelegates: [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        AppLocalizations.delegate,
        // This is generated automatically by intl package
      ],
      home: LoginPage(),
    );
  }
}
